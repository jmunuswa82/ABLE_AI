# ALS Patch Package

Original file: raw 1.als
SHA-256: 4e39b305fcebcda1b14080a64d11314f22e1cb057a2024b19bbca732866d9085
Generated: 2026-03-22T21:50:55.382Z

## Contents

- `original/` — Your original .als file (byte-for-byte preserved, no re-serialisation)
- `analysis/project-graph.json` — Full parsed project structure
- `analysis/completion-plan.json` — AI completion plan with ranked actions and mutation payloads
- `analysis/completion-instructions.md` — Human-readable completion guide
- `analysis/preservation-report.json` — SHA-256 hash, file size, and list of inferred fields
- `manifest.json` — Package metadata

## How to Use

1. Open `analysis/completion-instructions.md` for step-by-step guidance
2. Open `original/raw 1.als` in Ableton Live
4. Follow the completion plan actions in priority order
5. Reference `analysis/project-graph.json` for detailed track/clip data
