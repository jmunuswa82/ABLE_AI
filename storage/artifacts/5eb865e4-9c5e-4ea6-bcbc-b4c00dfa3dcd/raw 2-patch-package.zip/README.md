# ALS Patch Package

Original file: raw 2.als
SHA-256: bfca281e99e525e006c55c39d84fd9cbaaf17563553113ea765605d6b34e6eaa
Generated: 2026-03-23T00:08:32.168Z

## Contents

- `original/` — Your original .als file (byte-for-byte preserved, no re-serialisation)
- `patched/` — AI-patched .als candidate (trust: STRUCTURALLY_VALID_ALS, 6 mutations applied, 2 skipped)
- `analysis/project-graph.json` — Full parsed project structure
- `analysis/completion-plan.json` — AI completion plan with ranked actions and mutation payloads
- `analysis/completion-instructions.md` — Human-readable completion guide
- `analysis/preservation-report.json` — SHA-256 hash, file size, and list of inferred fields
- `manifest.json` — Package metadata

## How to Use

1. Open `analysis/completion-instructions.md` for step-by-step guidance
2. Open `original/raw 2.als` in Ableton Live
3. (Optional) Open the patched ALS in `patched/` — trust label: STRUCTURALLY_VALID_ALS
   - SAFE_LOCATOR_ONLY: Only locator markers were added
   - SAFE_AUTOMATION_ADDED: Locators + automation envelopes added
   - STRUCTURALLY_VALID_ALS: Clips were also added (review before using in a live set)
   - REQUIRES_MANUAL_REVIEW: Mutations required manual steps (not auto-applied)
4. Follow the completion plan actions in priority order
5. Reference `analysis/project-graph.json` for detailed track/clip data
