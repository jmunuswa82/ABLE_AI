# ALS Patch Package

Original file: raw 2.als
SHA-256: b7be01db74435e1190e54fd9750a39747b38435f7385e8b3f28f7526d09881db
Generated: 2026-03-21T19:37:32.947Z

## Contents

- `original/` — Your original .als file (byte-for-byte preserved, no re-serialisation)
- `analysis/project-graph.json` — Full parsed project structure
- `analysis/completion-plan.json` — AI completion plan with ranked actions and mutation payloads
- `analysis/completion-instructions.md` — Human-readable completion guide
- `analysis/preservation-report.json` — SHA-256 hash, file size, and list of inferred fields
- `manifest.json` — Package metadata

## How to Use

1. Open `analysis/completion-instructions.md` for step-by-step guidance
2. Open `original/raw 2.als` in Ableton Live
4. Follow the completion plan actions in priority order
5. Reference `analysis/project-graph.json` for detailed track/clip data
